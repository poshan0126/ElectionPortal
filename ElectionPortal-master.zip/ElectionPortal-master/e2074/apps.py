from django.apps import AppConfig


class E2074Config(AppConfig):
    name = 'e2074'
