# ElectionPortal
Discover everything election! This Repo is committed for providing free, comprehensive, standardized, linked set of election data. Simple, authentic, faster.


Use the settings.py.save as settings.py

Run the Folling.

`python manage.py makemigrations`

`python manage.py migrate`

`python manage.py collectstatic`

